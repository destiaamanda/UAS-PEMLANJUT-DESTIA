<?php  
if (isset($_SESSION["id_member"])) {	
	header("location:dasbor/index.php");
}
else {
	
}
?>