<?php  
if (isset($_SESSION["id_member"])) {	

}
else {
	header("location:../index.php");
}
?>